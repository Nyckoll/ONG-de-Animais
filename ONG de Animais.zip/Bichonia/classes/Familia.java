package classes;

public class Familia extends Pessoa{
	public String endereco;
	
	public Familia(){
		super();
		this.nome=nome;
		this.cpf=cpf;
		this.telefone=telefone;
		this.endereco=endereco;
	}

	public String getEndereco() {
		return adocao;
	}

	public void setEndereco(String endereco) {
		this.adocao = adocao;
	}
	

}
