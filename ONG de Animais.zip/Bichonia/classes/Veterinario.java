package classes;

public class Veterinario extends Pessoa{
	
	public String matricula_veterinario;

	public Veterinario(){
		super();
		this.matricula_veterinario=matricula_veterinario;
	}
	
	public String getMatricula_veterinario() {
		return matricula_veterinario;
	}

	public void setMatricula_veterinario(String matricula_veterinario) {
		this.matricula_veterinario = matricula_veterinario;
	}
	

}
