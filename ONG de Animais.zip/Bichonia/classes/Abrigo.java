package classes;

public class Abrigo {
	public String cod_abrigo;
	public String nome_abrigo;
	
	public Abrigo(){
		this.cod_abrigo=cod_abrigo;
		this.nome_abrigo= nome_abrigo;
	}
	
	public String getCod_abrigo() {
		return cod_abrigo;
	}
	public void setCod_abrigo(String cod_abrigo) {
		this.cod_abrigo = cod_abrigo;
	}
	public String getNome_abrigo() {
		return nome_abrigo;
	}
	public void setNome_abrigo(String nome_abrigo) {
		this.nome_abrigo = nome_abrigo;
	}
	
	

}
